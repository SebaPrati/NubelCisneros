
const initialState ={
    history: [],
    forecast: [],
    tempMax: 0,
    promMax: 0,
    promMin: 0,
    ciudad: "Montevideo",
    horaLocal: "",
    temperaturas: []
};
// const pepe = {
//     min: 0, 
//     max: 0
// }
export default initialState;